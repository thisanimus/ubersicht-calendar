# ubersicht-calendar
A simple js-based calendar for Ubersicht

![Screenshot of calendar](/screenshot.png?raw=true)

Ever since upgrading to Big Sur, I've been having trouble using Ubersicht widgets that rely on macOS system utilites as a data source.  Because of this, I decided to make a calendar widget that relies only on JS.